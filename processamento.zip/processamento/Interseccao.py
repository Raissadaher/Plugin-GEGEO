from qgis.core import QgsApplication, QgsProject, QgsVectorLayer
from qgis.analysis import QgsNativeAlgorithms
from qgis.core.additions import processing


class Interseccao:
    def __init__(self):
        QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
        self.supressao = None
        self.preservacao = None
        self.reserva_legal = None

    def executar(self):
        self.carregar_camadas()
        if self.supressao and self.preservacao and self.reserva_legal:
            self.processamento()
        else:
            print("Falha ao carregar uma ou mais camadas necessárias.")

    def carregar_camadas(self):
        self.supressao = QgsProject.instance().mapLayersByName('Área de supressão')[0]
        self.preservacao = QgsProject.instance().mapLayersByName('Área de preservação permanente')[0]
        self.reserva_legal = QgsProject.instance().mapLayersByName('Reserva legal')[0]

    def processamento(self):
        params_dissolucao_preservacao = {
            'INPUT': self.preservacao,
            'FIELD': None,  # Campo de dissolução (None para dissolver tudo)
            'OUTPUT': 'memory:'
        }
        result_dissolucao_preservacao = processing.run("native:dissolve", params_dissolucao_preservacao)
        if result_dissolucao_preservacao and result_dissolucao_preservacao['OUTPUT']:
            layer_dissolucao = result_dissolucao_preservacao['OUTPUT']
            layer_dissolucao.setName("APP Dissolvida")
            QgsProject.instance().addMapLayer(layer_dissolucao)

            params_interseccao = {
                'INPUT': self.supressao,
                'OVERLAY': layer_dissolucao,  # Utiliza a camada de preservação dissolvida como entrada
                'OUTPUT': 'memory:'
            }

            result_interseccao_sup_press_dissolvido = processing.run("native:intersection", params_interseccao)
            if result_interseccao_sup_press_dissolvido and result_interseccao_sup_press_dissolvido['OUTPUT']:
                layer_interseccao = result_interseccao_sup_press_dissolvido['OUTPUT']
                layer_interseccao.setName("Área de supressão APP")
                QgsProject.instance().addMapLayer(layer_interseccao)

                diferenca_sup_press_dissolvido = processing.run("native:difference", {
                    'INPUT': self.supressao,
                    'OVERLAY': layer_interseccao,
                    'OUTPUT': 'memory:'
                })

                if diferenca_sup_press_dissolvido and 'OUTPUT' in diferenca_sup_press_dissolvido:
                    layer_diferenca = diferenca_sup_press_dissolvido['OUTPUT']
                    layer_diferenca.setName("Diferença da supressão com a app")
                    QgsProject.instance().addMapLayer(layer_diferenca)

                    params_interseccao_rl = {
                        'INPUT': self.reserva_legal,
                        'OVERLAY': layer_diferenca,
                        'OUTPUT': 'memory:'
                    }

                    result_interseccao_rl = processing.run("native:intersection", params_interseccao_rl)
                    if result_interseccao_rl and 'OUTPUT' in result_interseccao_rl:
                        layer_interseccao_rl = result_interseccao_rl['OUTPUT']
                        layer_interseccao_rl.setName("Área de supressão em RL")
                        QgsProject.instance().addMapLayer(layer_interseccao_rl)

                        diferenca_interseccao_sup_rl = processing.run("native:difference", {
                            'INPUT': layer_diferenca,
                            'OVERLAY': layer_interseccao_rl,
                            'OUTPUT': 'memory:'
                        })

                        if diferenca_interseccao_sup_rl and 'OUTPUT' in diferenca_interseccao_sup_rl:
                            layer_diferenca_final = diferenca_interseccao_sup_rl['OUTPUT']
                            layer_diferenca_final.setName("Área de supressão fora")
                            QgsProject.instance().addMapLayer(layer_diferenca_final)
                            print("Processamento concluído com sucesso.")
                        else:
                            print("Falha ao executar a operação de diferença final.")
                    else:
                        print("Falha ao executar a operação de interseção com a reserva legal.")
                else:
                    print("Falha ao executar a operação de diferença com a área de supressão.")
            else:
                print("Falha ao executar a operação de interseção com a área de supressão.")
        else:
            print("Falha ao executar a operação de dissolução da área de preservação.")
