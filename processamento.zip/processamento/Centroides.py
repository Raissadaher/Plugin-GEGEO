from PyQt5.QtCore import QVariant
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsCoordinateReferenceSystem,
    QgsVectorFileWriter,
    QgsFeature,
    QgsGeometry, 
    QgsCoordinateTransform,
    edit
)

class Centroides:

    def __init__(self):
        self.project = QgsProject.instance()
        self.supressao = None
        self.centroides = None

    def executar(self):
        self.camada_sup()
        self.cria_centroides()
        self.transformar_sirgas()
        self.Lat_Long()
        self.carrega_camada()

    def camada_sup(self):
        supressao_layers = self.project.mapLayersByName('Área de supressão')
        if supressao_layers:
            self.supressao = supressao_layers[0]

    def cria_centroides(self):
        crs_project = self.project.crs()
        self.centroides = QgsVectorLayer(
            f'Point?crs={crs_project.authid()}&field=Área ha:double&field=Tipo:string&field=Data:string&field=id:int',
            'Centroides temp', 'memory'
        )
        if self.centroides:
            self.centroides.startEditing()

        self.centroides.dataProvider().addAttributes([
            QgsField('Área ha', QVariant.Double),
            QgsField('Tipo', QVariant.String),
            QgsField('Data', QVariant.String),
            QgsField('id', QVariant.Int)
        ])
        self.centroides.updateFields()

        for source_feature in self.supressao.getFeatures():
            geometry = source_feature.geometry()
            centroid = geometry.centroid()
            area = source_feature.attribute("Área ha")
            tipo = source_feature.attribute("Tipo")
            data = source_feature.attribute("Data")
            feature_id = source_feature.attribute("id")

            centroid_feature = QgsFeature()
            centroid_feature.setGeometry(centroid)
            centroid_feature.setAttributes([area, tipo, data, feature_id])
            self.centroides.addFeature(centroid_feature)

        self.centroides.commitChanges()

    def transformar_sirgas(self):
        crs_sirgas = QgsCoordinateReferenceSystem('EPSG:4674')
        self.centroides.setCrs(crs_sirgas)

    def Lat_Long(self):
        self.centroides.startEditing()
        self.centroides.dataProvider().addAttributes([
            QgsField("Lat", QVariant.Double, len=10, prec=4),
            QgsField("Long", QVariant.Double, len=10, prec=4)
        ])
        self.centroides.updateFields()

        crs_project = self.project.crs()
        crs_sirgas = QgsCoordinateReferenceSystem('EPSG:4674')
        transform = QgsCoordinateTransform(crs_sirgas, crs_project, self.project)

        for feature in self.centroides.getFeatures():
            point = transform.transform(feature.geometry().centroid().asPoint())
            lat = round(point.y(), 4)
            long = round(point.x(), 4)
            feature.setAttribute("Lat", lat)
            feature.setAttribute("Long", long)
            self.centroides.updateFeature(feature)

        self.centroides.commitChanges()
        print("Coordenadas de latitude e longitude adicionadas à tabela de atributos com precisão de 4 casas decimais.")

    def carrega_camada(self):
        if not self.centroides.isValid():
            print("Falha ao carregar a camada 'Centroides'.")
        else:
            QgsProject.instance().addMapLayer(self.centroides)
            print("Camada 'Centroides' adicionada ao projeto do QGIS com sucesso.")
