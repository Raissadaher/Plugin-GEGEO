from PyQt5.QtCore import QVariant
from qgis.core import (
    QgsApplication, QgsProject, QgsVectorLayer, QgsField,
    QgsCoordinateReferenceSystem, QgsProcessingFeatureSourceDefinition,
    QgsProcessing
)
from qgis.analysis import QgsNativeAlgorithms
import qgis.processing

class Interseccao:
    def __init__(self):
        QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())

    def executar(self):
        self.processamento()

    def adicionar_campo_area(self, layer):
        """Adiciona um campo 'Área ha' à camada e calcula a área em hectares para cada feição."""
        if layer is not None:
            layer.startEditing()
            if 'Area ha' not in [field.name() for field in layer.fields()]:
                layer.addAttribute(QgsField('Area ha', QVariant.Double))
                layer.updateFields()
            for feature in layer.getFeatures():
                area_ha = feature.geometry().area() / 10000
                layer.changeAttributeValue(feature.id(), layer.fields().indexFromName('Area ha'), round(area_ha, 4))
            layer.commitChanges()

    def reprojetar_camadas(self, layer, crs_destino):
        """Reprojeta uma camada para o sistema de referência de coordenadas especificado."""
        params_reproj = {
            'INPUT': layer,
            'TARGET_CRS': crs_destino,
            'OUTPUT': 'memory:'
        }
        result_reproj = qgis.processing.run("native:reprojectlayer", params_reproj)
        layer_reproj = result_reproj['OUTPUT']
        return layer_reproj

    def corrigir_geometria(self, layer):
        """Corrige geometria das feições na camada."""
        params_corrigir = {
            'INPUT': layer,
            'OUTPUT': 'memory:'
        }
        result_corrigir = qgis.processing.run("native:fixgeometries", params_corrigir)
        layer_corrigida = result_corrigir['OUTPUT']
        return layer_corrigida

    def processamento(self):
        try:
            supressao = QgsProject.instance().mapLayersByName('Área de supressão')[0]
            crs_supressao = supressao.crs().authid()
        except IndexError:
            print("Camada 'Área de supressão' não encontrada.")
            return

        try:
            preservacao = QgsProject.instance().mapLayersByName('Área de preservação permanente')[0]
        except IndexError:
            print("Camada 'Área de preservação permanente' não encontrada.")
            preservacao = None

        try:
            reserva_legal = QgsProject.instance().mapLayersByName('Reserva legal')[0]
        except IndexError:
            print("Camada 'Reserva legal' não encontrada.")
            reserva_legal = None

        if preservacao is None and reserva_legal is None:
            print("Nenhuma das camadas 'Área de preservação permanente' ou 'Reserva legal' foi encontrada.")
            return

        # Corrigir geometrias inválidas na camada "Área de supressão"
        supressao_corrigida = self.corrigir_geometria(supressao)

        if preservacao is not None:
            preservacao_reproj = self.reprojetar_camadas(preservacao, crs_supressao)
            preservacao_corrigida = self.corrigir_geometria(preservacao_reproj)

            # Dissolve Área de Preservação Permanente
            params_dissolucao_preservacao = {
                'INPUT': preservacao_corrigida,
                'FIELD': None,
                'OUTPUT': 'memory:'
            }
            result_dissolucao_preservacao = qgis.processing.run("native:dissolve", params_dissolucao_preservacao)
            layer_dissolucao = result_dissolucao_preservacao['OUTPUT']
            layer_dissolucao.setName("APP Dissolvida")

            # Interseção com APP Dissolvida
            params_interseccao = {
                'INPUT': supressao_corrigida,
                'OVERLAY': layer_dissolucao,
                'OUTPUT': 'memory:'
            }
            result_interseccao_sup_press_dissolvido = qgis.processing.run("native:intersection", params_interseccao)
            layer_interseccao = result_interseccao_sup_press_dissolvido['OUTPUT']
            layer_interseccao.setName("Área de supressão em APP")

            # Converter multipartes para partes simples
            result_interseccao_singles = qgis.processing.run("native:multiparttosingleparts", {
                'INPUT': layer_interseccao,
                'OUTPUT': 'memory:'
            })
            layer_interseccao_singles = result_interseccao_singles['OUTPUT']
            layer_interseccao_singles.setName("Área de supressão em APP")
            QgsProject.instance().addMapLayer(layer_interseccao_singles)

            # Adicionar campo e calcular área para "Área de supressão APP"
            self.adicionar_campo_area(layer_interseccao_singles)

            # Diferença da supressão com APP
            params_diferenca_sup_press_dissolvido = {
                'INPUT': supressao_corrigida,
                'OVERLAY': layer_interseccao_singles,
                'OUTPUT': 'memory:'
            }
            result_diferenca_sup_press_dissolvido = qgis.processing.run("native:difference", params_diferenca_sup_press_dissolvido)
            layer_diferenca = result_diferenca_sup_press_dissolvido['OUTPUT']
            layer_diferenca.setName("Diferença da supressão com a app")
        else:
            layer_diferenca = supressao_corrigida

        if reserva_legal is not None:
            reserva_legal_reproj = self.reprojetar_camadas(reserva_legal, crs_supressao)
            reserva_legal_corrigida = self.corrigir_geometria(reserva_legal_reproj)

            # Dissolve Reserva Legal
            params_dissolucao_rl = {
                'INPUT': reserva_legal_corrigida,
                'FIELD': None,
                'OUTPUT': 'memory:'
            }
            result_dissolucao_rl = qgis.processing.run("native:dissolve", params_dissolucao_rl)
            layer_dissolucao_rl = result_dissolucao_rl['OUTPUT']
            layer_dissolucao_rl.setName("RL Dissolvida")

            # Interseção com RL Dissolvida
            params_interseccao_rl = {
                'INPUT': layer_dissolucao_rl,
                'OVERLAY': layer_diferenca,
                'OUTPUT': 'memory:'
            }
            result_interseccao_rl = qgis.processing.run("native:intersection", params_interseccao_rl)
            layer_interseccao_rl = result_interseccao_rl['OUTPUT']
            layer_interseccao_rl.setName("Área de supressão em RL")

            # Converter multipartes para partes simples
            result_interseccao_rl_singles = qgis.processing.run("native:multiparttosingleparts", {
                'INPUT': layer_interseccao_rl,
                'OUTPUT': 'memory:'
            })
            layer_interseccao_rl_singles = result_interseccao_rl_singles['OUTPUT']
            layer_interseccao_rl_singles.setName("Área de supressão em RL")
            QgsProject.instance().addMapLayer(layer_interseccao_rl_singles)

            # Verificação de camadas e impressão de depuração
            if layer_interseccao_rl_singles.featureCount() == 0:
                print("Interseção com RL Dissolvida resultou em 0 feições.")

            # Adicionar campo e calcular área para "Área de supressão em RL"
            self.adicionar_campo_area(layer_interseccao_rl_singles)

            # Diferença final para encontrar "Área de supressão fora"
            params_diferenca_interseccao_sup_rl = {
                'INPUT': layer_diferenca,
                'OVERLAY': layer_interseccao_rl_singles,
                'OUTPUT': 'memory:'
            }
            result_diferenca_interseccao_sup_rl = qgis.processing.run("native:difference", params_diferenca_interseccao_sup_rl)
            layer_diferenca_final = result_diferenca_interseccao_sup_rl['OUTPUT']
        else:
            layer_diferenca_final = layer_diferenca

        layer_diferenca_final.setName("Área de supressão fora")

        # Converter multipartes para partes simples
        result_diferenca_final_singles = qgis.processing.run("native:multiparttosingleparts", {
            'INPUT': layer_diferenca_final,
            'OUTPUT': 'memory:'
        })
        layer_diferenca_final_singles = result_diferenca_final_singles['OUTPUT']
        layer_diferenca_final_singles.setName("Área de supressão fora")
        QgsProject.instance().addMapLayer(layer_diferenca_final_singles)

        # Adicionar campo e calcular área para "Área de supressão fora"
        self.adicionar_campo_area(layer_diferenca_final_singles)

        print("Processamento concluído com sucesso.")
