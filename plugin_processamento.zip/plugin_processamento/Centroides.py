from PyQt5.QtCore import QVariant
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
)


class Centroides:

    def __init__(self):
        self.project = QgsProject.instance()

    def executar(self):
        self.camada_sup()
        self.cria_centroides()
        self.transformar_sirgas()
        self.add_lat_long()
        self.carrega_camada()

    def camada_sup(self):
        supressao_layers = self.project.mapLayersByName('Área de supressão')
        if supressao_layers:
            self.supressao = supressao_layers[0]
            self.crs = self.supressao.crs()

    def cria_centroides(self):
        crs = self.supressao.crs()
        self.centroides = QgsVectorLayer(
            'Point?crs=' + crs.authid() + '&field=Área_ha:double&field=Tipo:string&field=Data:string&field=id:int',
            'Centroides temp', 'memory'
        )
        if self.centroides.isValid():
            self.centroides.startEditing()

            self.centroides.dataProvider().addAttributes([
                QgsField('Área_ha', QVariant.Double),
                QgsField('Tipo', QVariant.String),
                QgsField('Data', QVariant.String),
                QgsField('id', QVariant.Int)
            ])
            self.centroides.updateFields()

            for source_feature in self.supressao.getFeatures():
                geometry = source_feature.geometry()
                centroid = geometry.centroid()
                area = source_feature['Área_ha']
                tipo = source_feature['Tipo']
                data = source_feature['Data']
                feature_id = source_feature['id']

                centroid_feature = QgsFeature(self.centroides.fields())
                centroid_feature.setGeometry(centroid)
                centroid_feature.setAttributes([area, tipo, data, feature_id])
                self.centroides.addFeature(centroid_feature)

            self.centroides.commitChanges()

    def transformar_sirgas(self):
        crs_sirgas = QgsCoordinateReferenceSystem('EPSG:4674')
        self.transform = QgsCoordinateTransform(self.crs, crs_sirgas, QgsProject.instance())
        self.centroides_sirgas = QgsVectorLayer(
            'Point?crs=' + crs_sirgas.authid() + '&field=Área_ha:double&field=Tipo:string&field=Data:string&field=id:int&field=Lat:double&field=Long:double',
            'Centroides temp SIRGAS 2000', 'memory'
        )

        if self.centroides_sirgas.isValid():
            self.centroides_sirgas.startEditing()
            self.centroides_sirgas.dataProvider().addAttributes([
                QgsField('Lat', QVariant.Double, len=10, prec=4),
                QgsField('Long', QVariant.Double, len=10, prec=4)
            ])
            self.centroides_sirgas.updateFields()

    def add_lat_long(self):
        for feature in self.centroides.getFeatures():
            geometry = feature.geometry()
            geometry.transform(self.transform)
            centroid = geometry.centroid().asPoint()
            lat = round(centroid.y(), 4)
            long = round(centroid.x(), 4)
            attributes = feature.attributes()
            attributes.extend([lat, long])

            centroid_feature = QgsFeature(self.centroides_sirgas.fields())
            centroid_feature.setGeometry(geometry)
            centroid_feature.setAttributes(attributes)
            self.centroides_sirgas.addFeature(centroid_feature)

        self.centroides_sirgas.commitChanges()

    def carrega_camada(self):
        if self.centroides_sirgas.isValid():
            QgsProject.instance().addMapLayer(self.centroides_sirgas)
            print("Camada 'Centroides temp SIRGAS 2000' adicionada ao projeto do QGIS com sucesso.")
        else:
            print("Falha ao criar a camada de centroides SIRGAS 2000.")
