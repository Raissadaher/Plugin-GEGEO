from PyQt5.QtCore import QVariant
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
)

class Centroides:
    def __init__(self):
        self.project = QgsProject.instance()
        self.supressao_layers = []

    def executar(self):
        self.camada_sup()
        self.cria_centroides()
        self.transformar_sirgas()
        self.add_lat_long()
        self.carrega_camada()

    def camada_sup(self):
        nomes_desejados = ['Área de supressão fora', 'Área de supressão em RL', 'Área de supressão em APP', 'Dano']
        for nome in nomes_desejados:
            layers = self.project.mapLayersByName(nome)
            if layers:
                self.supressao_layers.extend(layers)

    def cria_centroides(self):
        crs = self.supressao_layers[0].crs() if self.supressao_layers else QgsCoordinateReferenceSystem()
        self.centroides = QgsVectorLayer(
            'Point?crs=' + crs.authid() + '&field=Area ha:double&field=Tipo:string&field=Data:string&field=id:int',
            'Centroides', 'memory'
        )
        if self.centroides.isValid():
            self.centroides.startEditing()
            self.centroides.dataProvider().addAttributes([
                QgsField('Area ha', QVariant.Double),
                QgsField('Tipo', QVariant.String),
                QgsField('Data', QVariant.String),
                QgsField('id', QVariant.Int),
            ])
            self.centroides.updateFields()
            for layer in self.supressao_layers:
                for source_feature in layer.getFeatures():
                    geometry = source_feature.geometry()
                    if not geometry or geometry.isEmpty() or not geometry.isGeosValid():
                        continue
                    centroid = geometry.centroid()
                    area = source_feature['Area ha']
                    tipo = source_feature['Tipo']
                    data = source_feature['Data']
                    feature_id = source_feature['id']
                    centroid_feature = QgsFeature(self.centroides.fields())
                    centroid_feature.setGeometry(centroid)
                    centroid_feature.setAttributes([area, tipo, data, feature_id])
                    self.centroides.addFeature(centroid_feature)
            self.centroides.commitChanges()

    def transformar_sirgas(self):
        crs_sirgas = QgsCoordinateReferenceSystem('EPSG:4674')
        self.transform = QgsCoordinateTransform(self.supressao_layers[0].crs(), crs_sirgas, QgsProject.instance())
        self.centroides_sirgas = QgsVectorLayer(
            'Point?crs=' + crs_sirgas.authid() + '&field=Area ha:double&field=Tipo:string&field=Data:string&field=id:int&field=Lat:double&field=Long:double',
            'Centroides', 'memory'
        )
        if self.centroides_sirgas.isValid():
            self.centroides_sirgas.startEditing()
            self.centroides_sirgas.dataProvider().addAttributes([
                QgsField('Lat', QVariant.Double, len=10, prec=4),
                QgsField('Long', QVariant.Double, len=10, prec=4)
            ])
            self.centroides_sirgas.updateFields()

    def add_lat_long(self):
        for feature in self.centroides.getFeatures():
            geometry = feature.geometry()
            if not geometry or geometry.isEmpty():
                continue
            geometry.transform(self.transform)
            if geometry.isNull():
                continue
            centroid = geometry.asPoint()
            lat = round(centroid.y(), 4)
            long = round(centroid.x(), 4)
            attributes = feature.attributes()
            attributes.extend([lat, long])

            centroid_feature = QgsFeature(self.centroides_sirgas.fields())
            centroid_feature.setGeometry(geometry)
            centroid_feature.setAttributes(attributes)
            self.centroides_sirgas.addFeature(centroid_feature)

        self.centroides_sirgas.commitChanges()

    def carrega_camada(self):
        if self.centroides_sirgas.isValid():
            QgsProject.instance().addMapLayer(self.centroides_sirgas)
            print("Camada 'Centroides' adicionada ao projeto do QGIS com sucesso.")
        else:
            print("Falha ao criar a camada de centroides.")
