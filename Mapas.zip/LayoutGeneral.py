import os
import random
import math

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont
from qgis.core import *
from qgis.utils import iface
from datetime import date
from qgis.core import QgsProject, QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsMapLayer, \
    QgsLegendStyle, QgsFillSymbol


class LayoutGeneral:
    def __init__(self):
        self.project = QgsProject.instance()
        manager = self.project.layoutManager()
        self.layout = QgsPrintLayout(self.project)
        self.mapa = QgsLayoutItemMap(self.layout)
        self.mapa01 = QgsLayoutItemMap(self.layout)
        self.layoutName = f"pagina_{random.randint(1, 500)}"
        self.layout.initializeDefaults()
        self.layout.setName(self.layoutName)
        manager.addLayout(self.layout)
        self.page = QgsLayoutItemPage(self.layout)
        self.page.setPageSize('A4', QgsLayoutItemPage.Landscape)
        self.layout.pageCollection().addPage(self.page)

    def executar(self):
        self.adicionando_poligono_maior()
        self.adicionando_poligono_titulo()
        self.renderizar_mapa()
        self.mapa_localização()
        self.inserindo_texto_label01()
        self.inserindo_texto_label02()
        self.inserindo_texto_label03()
        self.inserindo_texto_label04()
        self.inserindo_texto_label05()
        self.criando_legenda()
        self.adicionando_titulo()
        self.adicionando_subtitulo()
        self.inserir_norte()
        self.inserir_logo()
        self.inserir_car()
        self.inserindo_grid()
        self.barra_de_escala()
        self.adicionando_tabela()

    def adicionando_poligono_maior(self):
        rectangle_maior = QgsLayoutItemShape(self.layout)
        rectangle_maior.setShapeType(QgsLayoutItemShape.Rectangle)
        rectangle_maior.setRect(0, 0, 0, 0)
        self.layout.addLayoutItem(rectangle_maior)
        rectangle_maior.attemptMove(QgsLayoutPoint(6, 3, QgsUnitTypes.LayoutMillimeters))
        rectangle_maior.attemptResize(QgsLayoutSize(287.717, 202.350, QgsUnitTypes.LayoutMillimeters))
        iface.openLayoutDesigner(self.layout)

    def adicionando_poligono_titulo(self):
        rectangle_titulo = QgsLayoutItemShape(self.layout)
        rectangle_titulo.setShapeType(QgsLayoutItemShape.Rectangle)
        rectangle_titulo.setRect(0, 0, 0, 0)
        self.layout.addLayoutItem(rectangle_titulo)
        rectangle_titulo.attemptMove(QgsLayoutPoint(212, 8, QgsUnitTypes.LayoutMillimeters))
        rectangle_titulo.attemptResize(QgsLayoutSize(77, 193.3, QgsUnitTypes.LayoutMillimeters))

    def renderizar_mapa(self):
        area_imovel: QgsMapLayer = self.project.mapLayersByName('Área do imóvel')[0]
        self.mapa = QgsLayoutItemMap(self.layout)
        self.mapa.setId("mapa_propriedade")
        self.mapa.setAtlasDriven(True)
        self.mapa.setFrameEnabled(True)
        self.mapa.setRect(0, 0, 200, 188)
        self.mapa.setExtent(area_imovel.extent())
        self.layout.addLayoutItem(self.mapa)
        self.mapa.attemptMove(QgsLayoutPoint(10, 8, QgsUnitTypes.LayoutMillimeters))
        self.mapa.attemptResize(QgsLayoutSize(200, 193.3, QgsUnitTypes.LayoutMillimeters))

    def mapa_localização(self):
        municipios: QgsMapLayer = self.project.mapLayersByName('Municipios')[0]
        pais: QgsMapLayer = self.project.mapLayersByName('Brasil')[0]
        self.mapa01 = QgsLayoutItemMap(self.layout)
        self.mapa01.setId("mapa_municipios")
        self.mapa01.setAtlasDriven(True)
        self.mapa01.setFrameEnabled(True)
        self.mapa01.setRect(0, 0, 170, 0)
        src_crs = QgsCoordinateReferenceSystem(4674)
        self.mapa01.setCrs(src_crs)
        self.mapa01.setLayers([municipios, pais])
        self.mapa01.setExtent(municipios.extent())
        self.mapa01.overview().setLinkedMap(self.mapa)
        # mapa01.overview().setFrameSymbol(frame_symbol)
        props = {"color": "0,255,0,0", "color_border": "red", "width_border": "4.0"}
        simbolo = QgsFillSymbol.createSimple(props)
        self.mapa01.overview().setFrameSymbol(simbolo)
        self.mapa01.setScale(6500000)
        self.layout.addLayoutItem(self.mapa01)
        self.mapa01.attemptMove(QgsLayoutPoint(216, 70, QgsUnitTypes.LayoutMillimeters))
        self.mapa01.attemptResize(QgsLayoutSize(69.700, 43.109, QgsUnitTypes.LayoutMillimeters))
        print("simbolo: {0}".format(simbolo))

    def inserindo_texto_label01(self):
        # MT
        mt = 'MT'
        map_label01 = QgsLayoutItemLabel(self.layout)
        map_label01.setText(mt)
        map_label01.setFont(QFont("Arial", 6))
        map_label01.setItemOpacity(1.0)
        map_label01.setBackgroundEnabled(1)
        map_label01.adjustSizeToText()
        self.layout.addLayoutItem(map_label01)
        map_label01.attemptResize(QgsLayoutSize(5, 3, QgsUnitTypes.LayoutMillimeters))
        map_label01.attemptMove(QgsLayoutPoint(225, 85, QgsUnitTypes.LayoutMillimeters))

    def inserindo_texto_label02(self):
        to = 'TO'
        map_label02 = QgsLayoutItemLabel(self.layout)
        map_label02.setText(to)
        map_label02.setFont(QFont("Arial", 6))
        map_label02.setItemOpacity(1.0)
        map_label02.setBackgroundEnabled(1)
        map_label02.adjustSizeToText()
        self.layout.addLayoutItem(map_label02)
        map_label02.attemptResize(QgsLayoutSize(5, 3, QgsUnitTypes.LayoutMillimeters))
        map_label02.attemptMove(QgsLayoutPoint(256, 71, QgsUnitTypes.LayoutMillimeters))

    def inserindo_texto_label03(self):
        ba = 'BA'
        map_label03 = QgsLayoutItemLabel(self.layout)
        map_label03.setText(ba)
        map_label03.setFont(QFont("Arial", 6))
        map_label03.setItemOpacity(1.0)
        map_label03.setBackgroundEnabled(1)
        map_label03.adjustSizeToText()
        self.layout.addLayoutItem(map_label03)
        map_label03.attemptResize(QgsLayoutSize(5, 3, QgsUnitTypes.LayoutMillimeters))
        map_label03.attemptMove(QgsLayoutPoint(280, 75, QgsUnitTypes.LayoutMillimeters))

    def inserindo_texto_label04(self):
        mg = 'MG'
        map_label04 = QgsLayoutItemLabel(self.layout)
        map_label04.setText(mg)
        map_label04.setFont(QFont("Arial", 6))
        map_label04.setItemOpacity(1.0)
        map_label04.setBackgroundEnabled(1)
        map_label04.adjustSizeToText()
        self.layout.addLayoutItem(map_label04)
        map_label04.attemptResize(QgsLayoutSize(5, 3, QgsUnitTypes.LayoutMillimeters))
        map_label04.attemptMove(QgsLayoutPoint(272, 105, QgsUnitTypes.LayoutMillimeters))

    def inserindo_texto_label05(self):
        ms = 'MS'
        map_label05 = QgsLayoutItemLabel(self.layout)
        map_label05.setText(ms)
        map_label05.setFont(QFont("Arial", 6))
        map_label05.setItemOpacity(1.0)
        map_label05.setBackgroundEnabled(1)
        map_label05.adjustSizeToText()
        self.layout.addLayoutItem(map_label05)
        map_label05.attemptResize(QgsLayoutSize(4, 3, QgsUnitTypes.LayoutMillimeters))
        map_label05.attemptMove(QgsLayoutPoint(222, 107, QgsUnitTypes.LayoutMillimeters))

    def criando_legenda(self):
        legenda = QgsLayoutItemLegend(self.layout)
        legenda.setTitle("Legenda")
        legenda_fonte = QFont("Arial", 8)
        legenda.rstyle(QgsLegendStyle.Symbol).setMargin(QgsLegendStyle.Top, 2)
        legenda.setSymbolHeight(3)
        legenda.adjustBoxSize()
        legenda.setStyleFont(QgsLegendStyle.Title, legenda_fonte)
        legenda.setStyleFont(QgsLegendStyle.Subgroup, legenda_fonte)
        legenda.setStyleFont(QgsLegendStyle.SymbolLabel, legenda_fonte)
        legenda.attemptMove(QgsLayoutPoint(216, 120, QgsUnitTypes.LayoutMillimeters))
        legenda.attemptResize(QgsLayoutSize(20, 20, QgsUnitTypes.LayoutMillimeters))
        legenda.setLinkedMap(self.mapa)
        legenda.setItemOpacity(1.0)
        legenda.setBackgroundEnabled(0.5)
        legenda.setLegendFilterByMapEnabled(True)
        legenda.refresh()
        self.layout.addLayoutItem(legenda)

    def adicionando_titulo(self):
        nome_camada = "Área do imóvel"
        layer = self.project.mapLayersByName(nome_camada)[0]

        if layer is None:
            print("adicionando_titulo: camada {} nao foi encontrada".format(nome_camada))
            return

        propriedade = ""
        proprietario = ""
        municipio = ""
        cpf = ""
        processo_sei = ""

        # Itera sobre as features selecionadas
        for feature in layer.getFeatures():
            try:
                propriedade = feature['nm_imovel']
            except KeyError:
                try:
                    propriedade = feature['nome']
                except KeyError:
                    pass

            try:
                proprietario = feature['proprietar']
            except KeyError:
                pass

            try:
                municipio = feature['municipio']
            except KeyError:
                pass

            try:
                cpf = feature['cpf_cnpj']
            except KeyError:
                pass

        titulo_texto = """MAPA DE SITUAÇÃO
        Propriedade: {}
        Proprietário: {}
        CPF/CNPJ: {}
        Municipio: {}
        Processo SEI: {}
        """.format(propriedade, proprietario, cpf, municipio, processo_sei)

        title = QgsLayoutItemLabel(self.layout)
        title.setText(titulo_texto)
        title.setFont(QFont("Arial", 9))
        title.adjustSizeToText()
        title.setHAlign(Qt.AlignCenter)
        self.layout.addLayoutItem(title)
        title.attemptResize(QgsLayoutSize(75, 32.956, QgsUnitTypes.LayoutMillimeters))
        title.attemptMove(QgsLayoutPoint(213, 35, QgsUnitTypes.LayoutMillimeters))

    def adicionando_subtitulo(self):
        dados_propriedade_subtitulo = f"""Sistema Geodésico: Sirgas 2000
        Sistema de coordenada: Projetado-UTM
        Formato: A4
        Escala numérica: 1:{math.floor(self.mapa.scale())}
        Fontes: SEMAD, CAR, MMA, Rede MAIS/MJSP
        Elaboração: 
        GEGEO / SEMAD-GO
        Data : {date.today().strftime("%d/%m/%Y")}
        """
        subtitle = QgsLayoutItemLabel(self.layout)
        subtitle.setText(dados_propriedade_subtitulo)
        subtitle.setFont(QFont("Arial", 7))
        subtitle.setRect(0, 0, 0, 0)
        subtitle.adjustSizeToText()
        subtitle.setHAlign(Qt.AlignCenter)
        self.layout.addLayoutItem(subtitle)
        subtitle.attemptMove(QgsLayoutPoint(215, 177, QgsUnitTypes.LayoutMillimeters))
        subtitle.attemptResize(QgsLayoutSize(70, 23.760, QgsUnitTypes.LayoutMillimeters))

    def inserir_norte(self):
        north = QgsLayoutItemPicture(self.layout)
        north.setPicturePath(os.path.join(os.path.dirname(__file__), 'assets', 'norte.svg'))
        self.layout.addLayoutItem(north)
        north.attemptMove(QgsLayoutPoint(245, 158, QgsUnitTypes.LayoutMillimeters))
        north.attemptResize(QgsLayoutSize(15, 15, QgsUnitTypes.LayoutMillimeters))

    def inserir_logo(self):
        logo = QgsLayoutItemPicture(self.layout)
        logo.setPicturePath(os.path.join(os.path.dirname(__file__), 'assets', 'Semad_Abreviada_positivo.png'))
        self.layout.addLayoutItem(logo)
        logo.attemptMove(QgsLayoutPoint(214, 10, QgsUnitTypes.LayoutMillimeters))
        logo.attemptResize(QgsLayoutSize(75, 20.5, QgsUnitTypes.LayoutMillimeters))

    def inserir_car(self):
        nome_camada = "Área do imóvel"
        area_imovel = self.project.mapLayersByName(nome_camada)[0]

        if area_imovel is None:
            print("inserir_car: camada {} nao foi encontrada".format(nome_camada))
            return

        car = ""

        # Itera sobre as features selecionadas
        for feature in area_imovel.getFeatures():
            # Tenta acessar o valor da coluna 'cod_imovel'
            try:
                car = feature['cod_imovel']
            except KeyError:
                # Se não encontrar a coluna 'cod_imovel', tenta pegar o valor da coluna 'recibo'
                try:
                    car = feature['recibo']
                except KeyError:
                    pass

        dados = "CAR: {}".format(car)

        car_layout = QgsLayoutItemLabel(self.layout)
        car_layout.setText(dados)
        car_layout.setFont(QFont("Arial", 7))
        car_layout.adjustSizeToText()
        car_layout.setHAlign(Qt.AlignLeft)
        self.layout.addLayoutItem(car_layout)
        car_layout.attemptResize(QgsLayoutSize(75, 4, QgsUnitTypes.LayoutMillimeters))
        car_layout.attemptMove(QgsLayoutPoint(10, 202, QgsUnitTypes.LayoutMillimeters))

    def inserindo_grid(self):
        self.mapa.grid().setEnabled(True)
        self.mapa.grid().setUnits(QgsLayoutItemMapGrid.DynamicPageSizeBased)
        self.mapa.grid().setMaximumIntervalWidth(50)
        self.mapa.grid().setMinimumIntervalWidth(45)
        self.mapa.grid().setAnnotationEnabled(True)
        self.mapa.grid().setGridLineWidth(0.1)
        self.mapa.grid().setAnnotationPrecision(0)
        self.mapa.grid().setAnnotationFrameDistance(1)
        self.mapa.grid().setAnnotationFontColor(QColor(0, 0, 0))
        self.mapa.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Right)
        self.mapa.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Top)
        self.mapa.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Bottom)
        self.mapa.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Bottom)
        self.mapa.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Bottom)
        self.mapa.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Left)
        self.mapa.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left)
        self.mapa.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Left)

    # Barra de escala
    def barra_de_escala(self):
        escala = QgsLayoutItemScaleBar(self.layout)
        escala.setStyle('Caixa Simples')
        escala.setLinkedMap(self.mapa)
        escala.setHeight(2)
        escala.setFont(QFont('Arial', 9))
        escala.applyDefaultSize()
        escala.attemptMove(QgsLayoutPoint(163.5, 188, QgsUnitTypes.LayoutMillimeters))
        self.layout.addLayoutItem(escala)

    def adicionando_tabela(self):
        centroides_gerais = self.project.mapLayersByName('Centroides gerais')[0]
        tabela_atributos = QgsLayoutItemAttributeTable.create(self.layout)
        tabela_atributos.setVectorLayer(centroides_gerais)
        tabela_atributos.setMaximumNumberOfFeatures(40)
        self.layout.addMultiFrame(tabela_atributos)
        frame2 = QgsLayoutFrame(self.layout, tabela_atributos)
        frame2.attemptResize(QgsLayoutSize(198.200, 224), True)
        frame2.attemptMove(QgsLayoutPoint(120, 220, QgsUnitTypes.LayoutMillimeters))
        tabela_atributos.addFrame(frame2)
        # TODO ajustar resize mode
        tabela_atributos.setResizeMode(1)

        coluna = QgsLayoutTableColumn()
        coluna.setAttribute('id')  # First column name in your case. You can also put an expression
        coluna.setSortOrder(0)  # 0 = Asc, 1 Desc
        tabela_atributos.setSortColumns([coluna])
        self.layout.refresh()

# Endereço do icone do plugin
# <a target="_blank" href="https://icons8.com/icon/86907/mapa-m%C3%BAndi">Mapa-múndi</a> ícone por <a target="_blank" href="https://icons8.com">Icons8</a>
